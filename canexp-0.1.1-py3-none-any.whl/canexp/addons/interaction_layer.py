import threading
import time
from typing import Callable, Dict, Iterable, List, Optional

import cantools.database
import cantools.database.namedsignalvalue

from canexp import BusABC, Message


class Sender:
    """用于控制报文的发送、停止和恢复

    Args:
        bus (BusABC): CAN通道对象，
        msg (canexp.Message): 要发送的报文
    """

    def __init__(self, bus: BusABC, msg: Message):
        self.bus = bus
        self.msg = msg
        self._tx_pending: Callable = None
        self._running = False
        self._sending = False
        self._condition = None
        self._thread = None

    def start(self) -> None:
        """启动发送报文的线程"""
        self._running = True
        self._sending = True
        self._condition = threading.Condition()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """结束发送报文的线程"""
        self._running = False

    def join(self) -> None:
        """Wait until the thread terminates."""
        self._thread.join()

    def _run(self) -> None:
        while self._running:
            if not self._sending:
                with self._condition:
                    self._condition.wait()

            if self._tx_pending:
                self._tx_pending(self.msg.arbitration_id, self.msg.dlc, self.msg.data)

            self.bus.send(self.msg)
            time.sleep(self.msg.period / 1000)

    def resume(self) -> None:
        """恢复发送报文，不结束线程"""
        if not self._sending:
            with self._condition:
                self._sending = True
                self._condition.notify_all()

    def pause(self) -> None:
        """暂停发送报文，不结束线程"""
        self._sending = False

    def set_msg(self, msg: Message):
        pass

    def set_tx_pending(self, callback: Callable) -> None:
        """设置可以在总线发送CAN报文之前更改报文数据的回调函数，回调函数应包含三个参数CAN报文的id、dlc、data"""
        self._tx_pending = callback


def to_can_message(
    msg: cantools.database.Message,
) -> Optional[Message]:
    """将cantools.database.Message对象转换为canexp.Message对象

    Args:
        msg (cantools.database.Message): cantools库的Message对象

    Returns:
        canexp.Message: canexp库的Message对象
    """

    def _get_default_data(message: cantools.database.Message) -> bytearray:
        """使用cantools.database.Message中的默认信号值将数据转为bytes"""
        signals = {}

        for signal in message.signals:
            if not signal.initial:
                signal.initial = signal.minimum

            signals[signal.name] = signal.initial

        return bytearray(message.encode(signals, strict=False))

    if not msg:
        return None

    canmsg = Message(
        arbitration_id=msg.frame_id,
        is_extended_id=msg.is_extended_frame,
        dlc=msg.length,
        is_fd=msg.is_fd,
        period=msg.cycle_time if msg.cycle_time else 10,
    )
    canmsg.data = _get_default_data(msg)
    return canmsg


def to_can_messages(
    messages: List[cantools.database.Message],
) -> Optional[List[Message]]:
    """批量将cantools.database.Message对象转换为canexp.Message对象"""
    if not messages:
        return None

    canmsgs = []

    for msg in messages:
        if msg.send_type == "Cyclic":
            canmsgs.append(to_can_message(msg))

    return canmsgs


class NetworkNode:
    """模拟CAN网络节点批量发送CAN报文

    Args:
        bus (BusABC): CAN通道对象，
        messages (Iterable[cantools.datase.Message]): 当前节点要发送的所有CAN报文，cantools库解析DBC得到的message对象
    """

    def __init__(self, bus: BusABC, messages: Iterable[cantools.database.Message]):
        self.messages = to_can_messages(messages)
        self.tasks = {msg.arbitration_id: Sender(bus, msg) for msg in self.messages}

    def start(self):
        """开始发送所有报文"""
        for task in self.tasks.values():
            task.start()

    def stop(self):
        """停止发送所有报文"""
        for task in self.tasks.values():
            task.stop()

    def join(self):
        """Wait until the thread terminates."""
        for task in self.tasks.values():
            task.join()

    def _get_task_by_id(self, msg_id: int) -> Optional[Sender]:
        """通过CAN报文id查找对应线程句柄，用来操作CAN报文停止或恢复等动作"""
        if msg_id and msg_id in self.tasks:
            return self.tasks[msg_id]

        return None

    def pause(self, msg_id: int = None) -> None:
        """暂停此节点下的指定ID报文的发送"""
        task = self._get_task_by_id(msg_id)

        if task:
            task.pause()

    def resume(self, msg_id: int = None) -> None:
        """恢复此节点下的指定id报文的发送"""
        task = self._get_task_by_id(msg_id)

        if task:
            task.resume()

    def set_message(self, message: Message):
        pass

    def set_tx_pending(self, callback: Callable) -> None:
        """设置可以在总线发送CAN报文之前更改报文数据的回调函数，回调函数应包含三个参数CAN报文的id、dlc、data"""
        for task in self.tasks.values():
            task.set_tx_pending(callback)

    def pause_all(self) -> None:
        """暂停此节点下所有报文的发送"""
        for task in self.tasks.values():
            task.pause()

    def resume_all(self) -> None:
        """恢复此节点下所有报文的发送"""
        for task in self.tasks.values():
            task.resume()


class ILControl:
    """向指定CAN总线自动发送给定的CAN报文

    Args:
        configs (Dict[BusABC, List[cantools.database.Message]]): 指定需要向Bus上发送的CAN报文
    """

    def __init__(
        self,
        configs: Dict[BusABC, List[cantools.database.Message]],
    ):
        self._configs = configs
        self._nodes: Dict[int, Optional[NetworkNode]] = {}
        self._tx_pendings: Dict[int, Optional[Callable]] = {}

    def set_tx_pending(self, callback: Callable, bus: BusABC = None):
        """设置可以在总线发送CAN报文之前更改报文数据的回调函数，回调函数应包含三个参数CAN报文的id、dlc、data

        Args:
            callback (Callable): 回调函数
            bus (BusABC): 要设置回调函数节点所在通道的对象，如果为None，则会将回调函数设置给所有节点

        Returns:
            None
        """
        if not bus:
            for k in self._configs.keys():
                self._tx_pendings[k._channel] = callback
        else:
            self._tx_pendings[bus._channel] = callback

    def _run(self):
        if not self._configs:
            return None

        for bus, messages in self._configs.items():
            node = NetworkNode(bus, messages)

            if bus._channel in self._tx_pendings:
                node.set_tx_pending(self._tx_pendings[bus._channel])

            node.start()
            self._nodes[bus._channel] = node

    def start(self) -> None:
        """开始发送报文"""
        self._run()

    def stop(self) -> None:
        """停止发送报文"""
        for node in self._nodes.values():
            node.stop()

    def pause(self, id: int, bus: BusABC = None) -> None:
        """暂停发送指定ID的报文

        Args:
            id (int): 要停止发送的报文ID
            bus (BusABC): 报文所在的CAN通道对象，默认为None，如果此参数为None，会将所有通道的指定ID的报文停止发送

        Returns:
            None
        """
        if not bus:
            for node in self._nodes.values():
                if node:
                    node.pause(id)
        else:
            self._nodes[bus._channel].pause(id)

    def resume(self, id: int, bus: BusABC = None) -> None:
        """恢复发送指定ID的报文

        Args:
            id (int): 要恢复发送的报文ID
            bus (BusABC): 报文所在的CAN通道对象，默认为None，如果此参数为None，会将所有通道的指定ID的报文恢复发送

        Returns:
            None
        """
        if not bus:
            for node in self._nodes.values():
                if node:
                    node.resume(id)
        else:
            self._nodes[bus._channel].resume(id)

    def pause_all(self) -> None:
        """暂停发送所有报文"""
        for node in self._nodes.values():
            node.pause_all()

    def resume_all(self) -> None:
        """恢复发送所有报文"""
        for node in self._nodes.values():
            node.resume_all()
