import os
import time
import pathlib
from typing import Any, List, Optional, TextIO, Union, BinaryIO

import can
import can.io.generic

StringPathLike = Union[str, "os.PathLike[str]"]
MessageWriter = can.io.generic.MessageWriter
LogWriter = Union[can.Printer, can.ASCWriter, can.BLFWriter, Any]


def _check_message(
    msg: can.Message, filters: Optional[Union[List[int]]]
) -> Optional[can.Message]:
    """检查接收的消息是否满足过滤条件

    Args:
        msg (can.Message): 接收的消息
        filters (List[int]): 要过滤报文的ID列表

    Returns:
        can.Message or None
    """
    if not isinstance(filters, list) or msg.arbitration_id in filters:
        msg.timestamp = time.perf_counter()
        return msg

    return None


class BufferReader(can.BufferedReader):
    def __init__(self, can_filters: Optional[List[int]]):
        super().__init__()
        self.can_filters = can_filters

    def on_message_received(self, msg: can.Message) -> None:
        """接收消息处理函数"""
        if msg := _check_message(msg, self.can_filters):
            super().on_message_received(msg)


class Printer(can.Printer):
    def __init__(
        self,
        file: Optional[Union[StringPathLike, TextIO]] = None,
        can_filters: Optional[List[int]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(file, **kwargs)
        self.can_filters = can_filters

    def on_message_received(self, msg: can.Message) -> None:
        """接收消息处理函数"""
        if msg := _check_message(msg, self.can_filters):
            super().on_message_received(msg)


class ASCWriter(can.ASCWriter):
    def __init__(
        self,
        file: Union[StringPathLike, TextIO],
        can_filters: Optional[List[int]] = None,
        **kwargs,
    ):
        super().__init__(file, **kwargs)
        self.can_filters = can_filters

    def on_message_received(self, msg: can.Message) -> None:
        """接收消息处理函数"""
        if msg := _check_message(msg, self.can_filters):
            super().on_message_received(msg)


class BLFWriter(can.BLFWriter):
    def __init__(
        self,
        file: Union[StringPathLike, BinaryIO],
        can_filters: Optional[List[int]] = None,
        **kwargs,
    ):
        super().__init__(file, **kwargs)
        self.can_filters = can_filters

    def on_message_received(self, msg: can.Message) -> None:
        """接收消息处理函数"""
        if msg := _check_message(msg, self.can_filters):
            super().on_message_received(msg)


MESSAGE_WRITERS = {".txt": Printer, ".asc": ASCWriter, ".blf": BLFWriter}


def Logger(
    filename: Optional[StringPathLike],
    can_filters: Optional[List[int]] = None,
    **kwargs: Any,
) -> MessageWriter:
    """Find and return the appropriate :class:`~can.io.generic.MessageWriter` instance for a given file suffix."""
    if filename is None:
        return Printer(can_filters=can_filters)

    pathobj = pathlib.Path(filename)
    pathobj.parent.mkdir(parents=True, exist_ok=True)
    suffix = pathobj.suffix

    if suffix.lower() in MESSAGE_WRITERS:
        logger_type = MESSAGE_WRITERS[suffix]
        return logger_type(filename, can_filters, **kwargs)

    return can.Logger(filename, **kwargs)
