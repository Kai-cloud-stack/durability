from typing import Awaitable, Callable, Iterable, List, Union

import can
import can.notifier

BusABC = can.BusABC
Listener = can.Listener
Message = can.Message
MessageRecipient = Union[Listener, Callable[[Message], Union[Awaitable[None], None]]]


class Notifier(can.Notifier):
    def __init__(
        self,
        bus: Union[BusABC, List[BusABC]],
        listener: Union[MessageRecipient, Iterable[MessageRecipient]],
        **kwargs,
    ) -> None:
        listeners = listener if isinstance(listener, Iterable) else [listener]
        super().__init__(bus, listeners, **kwargs)
        buses = self.bus if isinstance(self.bus, list) else [self.bus]

        for each_bus in buses:
            self._setattr(each_bus)

    def _setattr(self, bus: BusABC) -> None:
        """将_listeners、_lock属性传递给BusABC对象"""
        if hasattr(bus, "_listeners"):
            bus._listeners = self.listeners.copy()

        if hasattr(bus, "_lock"):
            bus._lock = self._lock
