import time
from typing import Any, Optional, Sequence, Union, cast

import can
import can.interfaces.vector


class VectorBus(can.interfaces.vector.VectorBus):
    """The CAN Bus implemented for the Vector interface."""

    def __init__(
        self,
        channel: Union[int, Sequence[int], str],
        app_name: Optional[str] = "PythonCAN",
        bitrate: Optional[int] = 500_000,
        fd: bool = True,
        data_bitrate: Optional[int] = 2000_000,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            channel=channel,
            app_name=app_name,
            bitrate=bitrate,
            fd=fd,
            data_bitrate=data_bitrate,
            **kwargs,
        )
        self._channel = channel
        self._listeners = []
        self._lock = None

    def send(self, msg: can.Message) -> None:
        msg = self._check_message(msg)
        super().send(msg)
        self._on_message_sended(msg)

    def _check_message(self, msg: can.Message) -> can.Message:
        """检查并填充要发送消息的timestamp、dir、channel属性"""
        msg.timestamp = time.perf_counter()
        msg.is_rx = False
        msg.channel = self._channel
        return msg

    def _on_message_sended(self, msg: can.Message) -> None:
        """消息在发送后调用logger进行落盘或者回显操作

        Args:
            msg (can.Message): 发送的消息

        Returns:
            None
        """
        if not self._lock or not self._listeners:
            return None

        with self._lock:
            for callback in self._listeners:
                callback(msg)


def Bus(
    channel: Union[int, Sequence[int], str], interface: str = "vector", **kwargs
) -> can.bus.BusABC:
    """Create a new bus instance with configuration loading."""
    if interface == "vector":
        return cast(can.bus.BusABC, VectorBus(channel=channel, **kwargs))

    return can.interface.Bus(channel=channel, interface=interface, **kwargs)
