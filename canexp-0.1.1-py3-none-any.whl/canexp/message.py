import can


class Message(can.Message):
    def __init__(
        self,
        timestamp=0,
        arbitration_id=0,
        is_extended_id=True,
        is_remote_frame=False,
        is_error_frame=False,
        channel=None,
        dlc=None,
        data=None,
        is_fd=False,
        is_rx=True,
        bitrate_switch=False,
        error_state_indicator=False,
        check=False,
        period=10,
        tx_node=None,
    ):
        super().__init__(
            timestamp,
            arbitration_id,
            is_extended_id,
            is_remote_frame,
            is_error_frame,
            channel,
            dlc,
            data,
            is_fd,
            is_rx,
            bitrate_switch,
            error_state_indicator,
            check,
        )
        self.period = period
        self.tx_node = tx_node
